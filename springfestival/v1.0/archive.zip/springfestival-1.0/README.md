## 新春烟火发射器 v1.0

网页链接：<https://hensier.github.io/springfestival/>

### 历史版本

- v1.0 2023.1.1

### 致谢

本作品的源码参考了 [corestudi0](https://github.com/corestudi0) 的 [newyear](https://github.com/corestudi0/corestudi0.github.io/tree/d51966ce536e14c6c422f8e6587125911c7e52fc/newyear)，并加以修改以适用于新春祝福。

烟火元素选用了 [NianBroken](https://github.com/NianBroken) 的 [Firework_Simulator](https://github.com/NianBroken/Firework_Simulator)，未对其进行修改。
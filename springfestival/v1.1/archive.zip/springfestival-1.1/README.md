## 新春烟火发射器 v1.1

网页链接：<https://hensier.github.io/springfestival/>

### 历史版本

- v1.1 2023.1.2

    - 引入了 [NianBroken/Firework_Simulator](https://github.com/NianBroken/Firework_Simulator/tree/ac5644aef4aecccbe1ece8d9f5373f63dc6e6978) 的烟火调节功能。
    - 删去了之前引自 [corestudi0/newyear](https://github.com/corestudi0/corestudi0.github.io/tree/d51966ce536e14c6c422f8e6587125911c7e52fc/newyear) 的祝福文案，文案处暂时留白。
    - 添加了网页图标。

- v1.0 2023.1.1

### 致谢

本作品的逐字渲染功能和爆竹图片引入部分参考了 [corestudi0/newyear](https://github.com/corestudi0/corestudi0.github.io/tree/d51966ce536e14c6c422f8e6587125911c7e52fc/newyear) 的代码片段。

烟火部分引入了 [NianBroken/Firework_Simulator](https://github.com/NianBroken/Firework_Simulator/tree/ac5644aef4aecccbe1ece8d9f5373f63dc6e6978) 的实现。